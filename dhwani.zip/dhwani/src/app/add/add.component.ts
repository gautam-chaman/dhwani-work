import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
title='chaman gautam';
datasaved=false;
bookForm:FormGroup;
allbooks:Observable<Book[]>;
BookitoUpdate=null;

  constructor(private formbuilder:FormBuilder, private bookservice:BookService) { }
ngOnInit(){
  this.bookForm=this.formbuilder.group({
    name:[' ',[Validators.required]],
    Author:[' ',[Validators.required]],
    category:[' ',[Validators.required]]




  });
  this.getsoftBooks();
}

BooktoEdit(bookid:string){
  this.bookservice.getbookbyid(bookid).subscribe(book=>{
    this.BookitoUpdate=bookid;
    this.bookForm.controls['name'].setValue(book.name);
    this.bookForm.controls['category'].setValue(book.category);

    this.bookForm.controls['Author'].setValue(book.Author);

  })

}

onFormSubmit(){
  this.datasaved=false;
  let book=this.bookForm.value;
  this.createbooks(book);
  this.bookForm.reset();
}
createbooks(book:Book){
  if(this.BookitoUpdate==null){

  this.bookservice.createbook(book).subscribe(book=>{
    this.datasaved=true;
    this.getsoftBooks();

  });
}else{
  book.id=this.BookitoUpdate
  this.bookservice.Updatebook(book).subscribe(book=>{
    this.datasaved=true;
    this.getsoftBooks();
    this.BookitoUpdate=null;
  })
}

}
 getsoftBooks(){
this.allbooks=this.bookservice.getBooksFromStore();
 }

 BookDelete(bookid:string){
   this.bookservice.BookDelete(bookid)
   .subscribe(book=>{
     this.getsoftBooks();
   })
 }
}
