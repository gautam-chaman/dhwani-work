export interface Book{
id:number;
name:string;
Author:string;
category:string
}