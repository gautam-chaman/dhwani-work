import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loops',
  templateUrl: './loops.component.html',
  styleUrls: ['./loops.component.css']
})
export class LoopsComponent {

  students:any[] =[
{ 'name':'Chaman Gautam'},
{ 'name':'Ravi Gautam'},
{ 'name':'Mohit sharma'},
{ 'name':'Gaurav Sharma'},
{ 'name':'Gaurav Kumar'},
{ 'name':'Sandeep singh'},
{ 'name':'Sumit Nimmi'},
{ 'name':'Deepak'},
{ 'name':'Vikas'}

  ];


}
