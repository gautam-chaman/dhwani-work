import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import{ Book} from '../book'

@Component({
  selector: 'app-showdata',
  templateUrl: './showdata.component.html',
  styleUrls: ['./showdata.component.css']
})
export class ShowdataComponent implements OnInit {

  title='chaman gautam';
  softBooks:Book[];
  constructor(private bookservice:BookService) { }

  ngOnInit(){

    this.getsoftBooks();

  }
getsoftBooks(){
  this.bookservice.getBooksFromStore().subscribe(books => this.softBooks=books);
}

}
