import{InMemoryDbService} from 'angular-in-memory-web-api'
export class TestData implements InMemoryDbService{
    createDb(){

        let BookDetails=[
            {id:100, name:'JAVA ', Author:'C#corner',category:'Software devcelopment'},
            {id:101, name:'C Language', Author:'Tpoint',category:'test'},
            {id:102, name:'Web Technology', Author:'Google',category:' devcelopment'},
            {id:103, name:'Angular', Author:'C#corner',category:'Software devcelopment'}
           
        ];
        return {
            books:BookDetails
        };
    }

}